import csv
from itertools import islice

csv_reader = csv.reader(open('/Users/sabrina/Downloads/amenities_input.csv'))

amenity_id = 1
amenity_dict = {}

with open('/Users/sabrina/Downloads/amenities_output.csv', 'w', newline='') as output_file:
    csv_writer = csv.writer(output_file, delimiter=',')
    csv_writer.writerow(['listing_id', 'amenity_id', 'amenity_type'])

    for line in islice(csv_reader, 1, None):
        listing_id = line[0]

        for item in line[1:]:
            if (item == ''):
                continue
            item = item.replace('[', '').replace(']', '').replace('"', '').strip()
            if (item in amenity_dict.keys()):
                csv_writer.writerow([listing_id, amenity_dict[item], item])
            else:
                amenity_id += 1
                amenity_dict[item] = amenity_id
                csv_writer.writerow([listing_id, amenity_id, item])

